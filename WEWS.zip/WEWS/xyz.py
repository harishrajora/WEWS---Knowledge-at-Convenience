Given(' Lambdatest tests on more than {int} web and mobile apps', function (int, callback){
//Write code here that turns the phrase above into concrete actions
callback(null,  'pending');
});
